<?php 
session_start();
include('messageboard.php');
$personid=$_SESSION['personid'];
$receiver=$_GET['contactid'];
$messagetext=$_GET['message'];
$runadd= new newAddTexMessage($personid, $receiver, $messagetext);
$result=$runadd->showreturn();

?>