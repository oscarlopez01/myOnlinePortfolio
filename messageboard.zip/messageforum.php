<?php
session_start();
include('messageboard.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message Board Authentication</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="assets/styles.css" rel="stylesheet" />
   
</head>
<body onload="loadNewContacts('loadContacts');" >
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
        <div class="container">
        <a href="#" class="navbar-brand">Message Board</a>
    </div>
    </nav>
    <!-- Top Section: User Currently Logged in -->
    <section class="bg-dark text-light p-6 text-center float-md-left">

        <div class="container-md col-md-4 float-md-end">
            <div class="card" style="width: 18rem;">
                <div class="card text-dark">
                    <h5 class="card-header"><?php $person=$_SESSION['currentuser'][0];
                    echo $person['prefix_name']." ".$person['first_name']." ".$person['middle_initial']." ".$person['last_name'];?></h5>
                    <?php echo $person['phone']."<br>".$person['city'].", ".$person['state']." ".$person['zip']."<br>"; ?> <br>
                    <a href="logout.php" class="btn btn-primary">logout</a>
                </div>
            </div>  
       </div>
    </div>
  </section>

  <!--FriendList-->     

  <section class="bg-dark text-light p-6 text-center float-md-left">

    <div class="container" >
            <input type="hidden" id='usermain' value="<?php echo $_SESSION['personid'];?>">
            <div id="loadContacts">

             </div>    
                <ol class="list-group list-group float-md-left" style="width:400px;">    
                <li class="list-group-item d-flex justify-content-between align-items-start">
                    <div class="ms-2 me-auto">
                    <div class="fw-bold"></div>
                    
                    </div>

                  
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#searchModal">
                    Add New Contact
                    </button>
                </li>
                </ol>
            <div id="loadContacts">

            </div>    

    </div>
    <!-- Scrollable modal -->
    <section>
<!-- Modal -->
<div class="modal fade" id="searchModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-dark" id="staticBackdropLabel">Search Employee Database</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
  
      </div>
      <div id="displayNewContactList" class="modal-body">
     
            <div style="width:300px"> 
                    <div class="input-group mb-4 has-validation">
                    <input type="text" class="form-control" name="fnamesearch" id="fnamesearch" placeholder="First Name" aria-label="firstname" aria-describedby="inputGroupPrepend" >
                    </div>
                    <div class="input-group mb-4 has-validation">
                        <input type="text" class="form-control" name="lastnamesearch" id="lastnamesearch" placeholder="Last name" aria-label="lastname" aria-describedby="inputGroupPrepend">
                    </div>
                    <div class="col-auto text-right">
                    <button type="submit" class="btn btn-primary mb-3" onclick="searchForNewContact('displayResultOfSearch');">Search </button>
                    </div>
                
            </div>
        
        <div id="displayResultOfSearch">
                </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onClick="">Close</button>
        </div>
    </div>
  </div>
</div>
    </section>
   <br>   
  </section>

   <!-- Comments-->

   <section><br><br>
        <div class="container">
            <div class="mb-3">
            <div id="textUserMain"></div> <!-- div where the (id) of the contact where the message-to will --> 
            <label for="exampleFormControlTextarea1" class="form-label">New Text</label>
            <textarea class="form-control" name="messageContent" id="messageContent" rows="3"> </textarea>
            <button class="badge bg-primary rounded-pill" onClick="addMessage()">Add New Message</button>
            </div> 
        </div>
   </section>

    <section  >
        
        <div class="container">
            <div id="loadMessages"> </div>

        </div>
    </section>


</body>
<script type="text/javascript" src="interactions.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</html>