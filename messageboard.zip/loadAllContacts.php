<?php
session_start();
include('messageboard.php');

$contactlist= new allRelatedUsers($_SESSION['personid']);
$getlist=$contactlist->showreturn();

if($getlist!=null){
?>
           <ol class="list-group list-group-numbered"  style="height:300px; overflow-y:scroll;">
                <?php foreach($getlist as $contact){ //contact start parsing object ?>
                <li class="list-group-item d-flex justify-content-between align-items-start" id="<?php echo $contact['connection_id']; ?>" >
                    <div class="ms-2 me-auto">
                    <div class="fw-bold"><?php
                    echo $contact['prefix_name']." ".$contact['first_name']." ".$contact['middle_initial']." ".$contact['last_name'];
                    ?></div>
                    <?php echo $contact['phone']."<br>".$contact['city'].", ".$contact['state']." ".$contact['zip']."<br>"; ?>
                    </div>
                    <span class="btn badge bg-primary rounded-pill" onclick="loadContact('textUserMain','<?php echo $contact['person_id']; ?>');">select</span>
                    <span class="btn badge bg-danger rounded-pill" onclick="deleteContact('<?php echo $contact['connection_id']; ?>');">x</span>

                </li>
                <?php } //contacts parsed object ?>
            </ol>
<?php } ?>