<?php

//Database connection class

class connhost{
   //credentials to access database
    protected $dbhost='localhost';
    protected $dbname='messageboard';
    protected $userdb='mbadmin';
    protected $passdb='XB0715s5102*';

    protected function connect(){ 
      $conn= new mysqli($this->dbhost, $this->userdb, $this->passdb, $this->dbname);
      if($conn->connect_error){
        $returndata["error"]=true;
         $returndata["errortype"]="connetion failed: ".$conn->connect_error;
         return $returndata;
      }
      
      
      return $conn;

    }

}


//message board crud class
class mdbCRUD extends connhost{



    //CREATE for C in CRUD
    public function Create($table,$fields,$record){

        $search="INSERT INTO ".$table." ".$fields." 
        VALUES
        ".$record;

        $result=parent::connect()->query($search);

        if($result===TRUE){
            $data['error']=0;
            return $data;
        }else{
            $data['error']=1;
            return $data;
        } 

    }

    //READ for R in CRuD
    protected function Read($search){
        $result=parent::connect()->query($search);

        $numrows=$result->num_rows;
        if($numrows>0){
            while($row=$result->fetch_assoc()){
                $data[]=$row;
            }
            return $data;
        }

    }

    //Update for U in CRUD
    public function Update($table, $updatedata){
        $search="UPDATE ".$table." ".$updatedata;
        $result=parent::connect()->query($search);

        $numrows=$result->num_rows;
        if($numrows>0){
            while($row=$result->fetch_assoc()){
                $data[]=$row;
            }
            return $data;
        }else{
            return null;
        }

    }

    //DELETE for D in CRUD
    public function Delete($rid,$table){
        $search="DELETE FROM ".$table." WHERE ".$rid;

        $result=parent::connect()->query($search);

        if($result===TRUE){
            $data['error']=0;
            return $data;
        }else{
            $data['error']=1;
            return $data;
        }    

    }

    public function __DESTRUCT(){
    
    }

}

//message board authentication class

class Authenticate extends mdbCRUD{

    private $result;

    public function __CONSTRUCT($user, $pass)
    {
        $sqlstm="SELECT person_id, passwdh FROM person Where email='".$user."'";
        $userData=parent::Read($sqlstm);

        if($userData!=null){ //test for null return.  
        foreach($userData as $data){
            if(password_verify($pass, $data['passwdh'])){
               $myreturns['person_id']=$data['person_id'];
               $myreturns['error']=false;
            }else{
                $myreturns['error']=true;
            }
        }
       }else{$myreturns['error']=true;} //return true to there being an error

       $this->result=$myreturns;
    }

    public function showreturn(){
        return $this->result;
    }
}


//load the primary user
class primaryUser extends mdbCRUD{

    private $user;

    public function __CONSTRUCT($personid){
        $sqlstm="SELECT prefix_name,first_name, middle_initial, last_name, dob, gender, phone, address1, state, city, zip, profile_status FROM person WHERE person_id='".$personid."'";
        $userData=parent::Read($sqlstm);
        
        foreach($userData as $data){
            
               $myreturns[]=$data;

        }
        $this->user=$myreturns;

    }

    public function showreturn(){

        return $this->user;
    }

}


// return a list of contacts related to primary account

class allRelatedUsers extends mdbCRUD{

    private $user;

    public function __CONSTRUCT($personid){
        $sqlstm="SELECT A.prefix_name, A.first_name, A.middle_initial, A.last_name, A.dob, A.gender, 
        A.phone, A.address1, A.state, A.city, A.zip, A.profile_status, A.person_id, B.connection_id, 
        B.person_id as myID FROM person as A INNER JOIN contact_list as B ON A.person_id=B.contact_id WHERE B.person_id='".$personid."'";
        $userData=parent::Read($sqlstm);
        
        if($userData!=null){ // if empty will return a  null result
            foreach($userData as $data){
                    if($data['myID']==$personid){
                $myreturns[]=$data;
                }else{
                    $myreturns['error']=TRUE;
                }
            }
            $this->user=$myreturns;
        }else{
            $this->user=null;
        }
    }

    public function showreturn(){

        return $this->user;
    }

}


// a class that returns a list of contacts from a search.

class searchContacts extends mdbCRUD{

    private $user;

    public function __CONSTRUCT( $searchName, $searchLast){ 
        $sqlstm="SELECT A.prefix_name, A.first_name, A.middle_initial, A.last_name, A.dob, 
        A.gender, A.phone, A.address1, A.state, A.city, A.zip, A.profile_status, A.person_id
         FROM person as A WHERE CONCAT(A.first_name, ' ', A.last_name) like '%".$searchName." ".$searchLast."%' ORDER BY A.last_name ASC";
        $userData=parent::Read($sqlstm);
        
        foreach($userData as $data){

               $myreturns[]=$data;
   
        }
        $this->user=$myreturns;

    }

    public function showreturn(){

        return $this->user;
    }

}


//deleting contacts 

class deleteContact extends mdbCRUD {
    private $user;

    public function __CONSTRUCT($connectionid){
        
        $userData=parent::Delete("connection_id='".$connectionid."'",'contact_list');
        
        foreach($userData as $data){
            
               $myreturns[]=$data;

        }
        $this->user=$myreturns;

    }

    public function showreturn(){

        return $this->user;
    }


}


// adding contacts to the primary account
class newAddContact extends mdbCRUD {
    private $user;

    public function __CONSTRUCT($personid, $contactid){

        $fieldlist="(connection_id, person_id, contact_id, relationship) ";
        $tablename="contact_list ";
        $contactrecord=" (UUID(), '".$personid."', '".$contactid."', 2)";
        
        $userData=parent::Create($tablename, $fieldlist, $contactrecord);
        
        foreach($userData as $data){
            
               $myreturns[]=$data;

        }
        $this->user=$myreturns;

    }

    public function showreturn(){

        return $this->user;
    }


}


//text contacts
class newAddTexMessage extends mdbCRUD {
    private $user;

    public function __CONSTRUCT($personid, $contactid, $message ){

        $fieldlist="(message_id, sender_id, receiver_id, message) ";
        $tablename="message ";
        $contactrecord=" (UUID(), '".$personid."', '".$contactid."', '".$message."')";
        
        $userData=parent::Create($tablename, $fieldlist, $contactrecord);
        
        foreach($userData as $data){
            
               $myreturns[]=$data;

        }
        $this->user=$myreturns;

    }

    public function showreturn(){

        return $this->user;
    }


}


// get all related messages for primaryuser between contact.

class loadAllRelatedMessages extends mdbCRUD{

    private $user;

    public function __CONSTRUCT( $personid, $contactid){ 
        $sqlstm="SELECT a.sender_id, a.receiver_id, a.message, a.send_datetime
        FROM message as a WHERE (a.sender_id='".$personid."' and a.receiver_id='".$contactid."')  or  
        (a.sender_id='".$contactid."' and a.receiver_id='".$personid."')
         ORDER BY a.send_datetime DESC ";
        $userData=parent::Read($sqlstm);
        if($userData!=null){ //test for null return.
        foreach($userData as $data){
            
               $myreturns[]=$data;
   
        }
        $myreturns["error"]=false;
        }else{$myreturns["error"]=true;}
        $this->user=$myreturns;

    }

    public function showreturn(){

        return $this->user;
    }

}

?>