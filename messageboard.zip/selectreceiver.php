<?php
session_start();
include('messageboard.php');

$contactlist= new primaryUser($_GET['receiver']);
$getlist=$contactlist->showreturn();



?>
           <ol class="list-group">
                <?php foreach($getlist as $contact){ //contact start parsing object ?>
                <li class="list-group-item d-flex justify-content-between align-items-start" >
                    <div class="ms-2 me-auto">
                    <div class="fw-bold"><?php
                    echo $contact['prefix_name']." ".$contact['first_name']." ".$contact['middle_initial']." ".$contact['last_name'];
                    ?></div>
                    <?php echo $contact['phone']."<br>".$contact['city'].", ".$contact['state']." ".$contact['zip']."<br>"; ?>
                    </div>
                    <input type="hidden" name="receivermainid" id="receivermainid" value="<?php echo $_GET['receiver']; ?>">
                </li>
                <?php } //contacts parsed object ?>
            </ol>