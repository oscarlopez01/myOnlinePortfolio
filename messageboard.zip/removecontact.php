<?php 
session_start();
include('messageboard.php');
$connectionid=$_GET['connid'];
$rundelete= new deleteContact($connectionid);
$result=$rundelete->showreturn();

echo $result[0];
?>