<?php 
session_start();
include('messageboard.php');
$personid=$_SESSION['personid'];
$connectionid=$_GET['contactid'];
$runadd= new newAddContact($personid, $connectionid);
$result=$runadd->showreturn();

echo $result[0];
?>