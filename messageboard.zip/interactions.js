function deleteContact(str) {
    if(confirm("Are you certain you want to delete this Contact from the list?")==true){

        if (str.length == 0) {
            document.getElementById(str).innerHTML;
            return;
        } else {
            const xmlhttp = new XMLHttpRequest();
            xmlhttp.onload = function() {
                if(this.responseText==0){
            //document.getElementById(str).innerHTML = "";
                loadNewContacts('loadContacts');    
                }
            }
        xmlhttp.open("GET", "removecontact.php?connid=" + str);
        xmlhttp.send();
        }
    }

}

function addPersonToContact(str){
    var userid=document.getElementById('usermain').innerHTML;
    if (str.length == 0) {
        document.getElementById(str).innerHTML = "";
        return;
    } else {
        const xmlhttp = new XMLHttpRequest();
        xmlhttp.onload = function() {
            
            if(this.responseText==0){
                loadNewContacts('loadContacts');
            }
        
        }
    xmlhttp.open("GET", `addNewContact.php?contactid=${str}&userid=${userid}`);
    xmlhttp.send();
    }
}

function loadNewContacts(str){

    if (str.length == 0) {
        document.getElementById(str).innerHTML = "";
        return;
    } else {
        const xmlhttp = new XMLHttpRequest();
        xmlhttp.onload = function() {
            
        document.getElementById(str).innerHTML =this.responseText;
        
        }
    xmlhttp.open("GET", "loadAllContacts.php");
    xmlhttp.send();
    }
}



function searchForNewContact(str){
     var name= document.getElementById('fnamesearch').innerHTML;
     var lastname= document.getElementById('lastnamesearch').innerHTML;
     var limit=20;
     var page= 1;
    if (str.length == 0) {
        document.getElementById(str).innerHTML = "";
        return;
    } else {
        const xmlhttp = new XMLHttpRequest();
        xmlhttp.onload = function() {
            
        document.getElementById(str).innerHTML =this.responseText;
        
        }
    xmlhttp.open("GET", "searchNewContact.php?first="+name+"&last="+lastname);
    xmlhttp.send();
    }
}

function loadContact(str,contactid){

    if (str.length == 0) {
        document.getElementById(str).innerHTML = "";
        return;
    } else {
        const xmlhttp = new XMLHttpRequest();
        xmlhttp.onload = function() {
            
        document.getElementById(str).innerHTML =this.responseText;
        loadMessages('loadMessages', contactid);

        }
    xmlhttp.open("GET", `selectreceiver.php?receiver=${contactid}`);
    xmlhttp.send();
    }
}

function addMessage(){
   let receiverid=document.getElementById('receivermainid').value;
    let messagedata=document.getElementById('messageContent').value;
    
    if (receiverid.length > 0 && messagedata.length>0) {
 
        const xmlhttp = new XMLHttpRequest();
        xmlhttp.onload = function() {
            
            if(this.responseText==0){
                //loadNewContacts('loadContacts');
                loadMessages('loadMessages',receiverid);
                document.getElementById('messageContent').value="";
            }
        
        }
    xmlhttp.open("GET", `submitmessage.php?contactid=${receiverid}&message=${messagedata}`);
    xmlhttp.send();
    }else{alert('Make sure there is a message');}
}

function loadMessages(str,contactid){

    if (str.length == 0) {
        document.getElementById(str).innerHTML = "";
        return;
    } else {
        const xmlhttp = new XMLHttpRequest();
        xmlhttp.onload = function() {
            
        document.getElementById(str).innerHTML =this.responseText;
        
        }
    xmlhttp.open("GET", `loadrelatedmessage.php?contactid=${contactid}`);
    xmlhttp.send();
    }
}