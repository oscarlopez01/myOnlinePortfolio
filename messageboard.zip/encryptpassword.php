<?php
    $dbname='messageboard';
    $userdb='mbadmin';
    $passdb='XB0715s5102*';

    try {
        $conn = new PDO("mysql:host=localhost;dbname=".$dbname, $userdb, $passdb);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "Connected successfully";
      } catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
      }

      $getrecords= $conn->query("SELECT person_id, passwd FROM person");

      foreach($getrecords as $record){
        echo $record['passwd']."<br>";
        echo $record['person_id']."<br>";
          $query="UPDATE person SET passwdh='".password_hash($record['passwd'], PASSWORD_DEFAULT)."' WHERE person_id='".$record['person_id']."'";
          echo $query."<br>";
          $conn->query($query);

      }

      $conn=null;
      ?>