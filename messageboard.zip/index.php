<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message Board Authentication</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="assets/styles.css" rel="stylesheet" />
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
        <div class="container">
        <a href="#" class="navbar-brand">Message Board</a>
    </div>
    </nav>
    <!-- Top Section: about the page -->
    <section class="bg-dark text-light p-5 text-center">
        <div class="container">
            <div class="clearfix">
                <img src="assets/smartphone-gfa2c8fb90_640.png" class="col-md-2 float-md-end mb-2 ms-md-2">
                <p> This message board was created to connect co-workers in an effort to collaborate. Use professional languague and follow work ethics.</p>
                <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>
            </div>

        </div>
    </section>
    <!-- Login page-->
    <section class="bg-light text-light p-5 text-right">
        <div class="container text-right">  
            <div style="width:300px"> 
                <form action="/authenticate.php" method="post" class="login">
                    <div class="input-group mb-4 has-validation">
                        <input type="text" class="form-control" name="username" placeholder="Username" aria-label="Username" aria-describedby="inputGroupPrepend" required>
                    </div>
                    <div class="input-group mb-4 has-validation">
                        <input type="password" class="form-control" name="password" placeholder="Password" aria-label="Password" aria-describedby="inputGroupPrepend" required>
                    </div>
                    <div class="col-auto text-right">
                    <button type="submit" class="btn btn-primary mb-3">Sign in</button>
                    </div>
                </form>
            </div>
        </div>  
    </section>   
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>


