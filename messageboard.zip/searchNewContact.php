<?php 
session_start();
include('messageboard.php');

$currentName=$_GET['first'];
$currentLast=$_GET['last'];


$runsearch= new searchContacts($currentName, $currentLast);
$search=$runsearch->showreturn();


?>

<ol class="list-group list-group-numbered"  style="height:300px; overflow-y:scroll;">
                <?php foreach($search as $contact){ //contact start parsing object ?>
                <li class="list-group-item d-flex justify-content-between align-items-start" >
                    <div class="ms-2 me-auto">
                    <div class="fw-bold"><?php
                    echo $contact['prefix_name']." ".$contact['first_name']." ".$contact['middle_initial']." ".$contact['last_name'];?>
                    </div>
                    <?php echo $contact['phone']."<br>".$contact['city'].", ".$contact['state']." ".$contact['zip']."<br>"; ?>
                    </div>
                    <span class="btn badge bg-primary rounded-pill" onclick="addPersonToContact('<?php echo $contact['person_id']; ?>');">select</span>
                   
                </li>
                <?php } //contacts parsed object ?>
            </ol>

        