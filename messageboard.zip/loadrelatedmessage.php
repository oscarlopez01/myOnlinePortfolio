<?php 
session_start();
include('messageboard.php');
$personid=$_SESSION['personid'];
$receiver=$_GET['contactid'];
$runadd= new loadAllRelatedMessages($personid, $receiver);
$result=$runadd->showreturn();
//var_dump($result);
$contactFUllName= new primaryUser($receiver);
$getContactFName=$contactFUllName->showreturn();
foreach($getContactFName as $receiverContact){
    $getContactID=$receiver;
    $getCcontactFName= $receiverContact['prefix_name']." ".$receiverContact['first_name']." ".$receiverContact['middle_initial']." ".$receiverContact['last_name'];
   
}


$primaryFUllName= new primaryUser($personid);
$primaryFName=$primaryFUllName->showreturn();
foreach($primaryFName as $primaryContact){
    
    $getPrimaryFullNamenow= $primaryContact['prefix_name']." ".$primaryContact['first_name']." ".$primaryContact['middle_initial']." ".$primaryContact['last_name'];
   
}


if($result["error"]!=true){
array_pop($result);
foreach($result as $message){
    $mheader= substr($message["message"],12);
    $mbody= $message["message"];
    $senderid=$message["sender_id"];
    $recepientid=$message["receiver_id"];

    if($getContactID==$senderid){

?>
<div class="d-flex flush-content-left"><h3><?php echo $getCcontactFName;?></h3></div>
<?php }elseif($personid==$senderid){ ?>
<div class="d-flex flush-content-right"><h3><?php echo $getPrimaryFullNamenow;?></h3></div>
<?php } ?>
<div class="list-group">
                <a href="#" class="list-group-item list-group-item-action" aria-current="true">
                    <div class="d-flex w-100 justify-content-between">
                   
                    <small class="left-content"><?php echo $message["send_datetime"]; ?></small>
                    </div>
                    <p class="mb-1"><?php echo $mbody; ?></p>
                    
                </a>
</div>
<?php 
}
}
?>