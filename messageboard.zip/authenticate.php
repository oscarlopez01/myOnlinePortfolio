<?php
    session_start();
    $username1=$_POST['username'];
    $password1=$_POST['password'];


include("messageboard.php");

 $testCredentials= new Authenticate($username1, $password1);
 $result=$testCredentials->showreturn();

  if($result['error']==false && $username1!="" && $password1!=""){
    
    $_SESSION['personid']=$result['person_id'];
    $resultuser= new primaryUser($result['person_id']);
    $_SESSION['currentuser']=$resultuser->showreturn();

   header( 'Location: http://localhost/messageforum.php');

  }else{

  header( 'Location: http://localhost/logout.php');
  }



?>
